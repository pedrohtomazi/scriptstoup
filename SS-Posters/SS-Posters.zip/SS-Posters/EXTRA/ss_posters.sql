CREATE TABLE IF NOT EXISTS `ss_posters` (
  `id` varchar(50) NOT NULL DEFAULT '0',
  `identifier` varchar(50) DEFAULT NULL,
  `charid` varchar(50) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `link` varchar(500) DEFAULT NULL,
  `pos` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
