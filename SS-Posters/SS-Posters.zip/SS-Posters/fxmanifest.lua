fx_version "bodacious"
games {"rdr3"}
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'
author 'SIREC'
description 'SS-Posters'
code 'SSPOSTERS'
version '1.4'
lua54 'yes'

ui_page 'UI/UI.html'

files {'UI/UI.html','UI/css/*.css','UI/js/*.js','UI/images/*.png'}

client_scripts {'config.lua','c/c.lua'}

server_scripts {'config.lua','@SS-Core/s/server.lua'}

escrow_ignore {'config.lua'}