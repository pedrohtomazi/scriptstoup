Config = {
    
Poster = "cocoa",
DEV = true,
Key = 0xD9D0E1C0,
PosterDistance = 1.5,
PosterDays = 1,
UseBlips = true,
Blip = -2018361632,
    
Webhook = "https://discord.com/api/webhooks/1075787750546100254/11JNQWZDQEC-BAadrD8MiNnQKjLvwEz_bg7IUaLJOTMTRAqVxAECLS5TtmQwZsoM8Wwo",

Objects = {
["p_telegraphpole02x"] = {0, -0.12999999999999, 1.58},
["p_telegraphpole08x"] = {0.05999999999999, -0.20999999999998, 1.62},
["p_telegraphpole05x"] = {0, -0.10999999999998, 1.62},
["p_telegraphpole04x"] = {0, -0.19999999999999, 1.62},
["p_telegraphpole06x"] = {-0.09, 0.07, 1.74},
["p_telegraphpole09x"] = {0.05999999999999, -0.20999999999998, 1.62},
["p_telegraphpole07x"] = {0.27, -0.07999999999998, 1.62},
},
    
Texts = {
["input_title"] = "POSTER LINK",
["input_info"] = "ADD IMAGES LINK",
["blips_name"] = "POSTER",
["already_post"] = "Dude, here is already a flyer, are you blind ?",
["discord_tittle"] = "NEW FLYER ADDED",
["cant_post"] = "You can't attach here the poster, There's no any telegraph pole !",
["can_post"] = "Perfect, now let's hope that somebody will read it !",
},

}

function NOTIFY(text) --SET YOUR NOTIFYCATIONS
TriggerEvent("vorp:TipBottom", text, 5000)   
end 