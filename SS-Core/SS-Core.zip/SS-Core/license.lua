YourSSLicense = "Your SS Account License" -- YOUR SS LICENSE (DON'T SHARE TO NOBODY)
SteamAccess = { -- What steam ID's are able to open SS Dashboard ?
    "steam:000000000000000",
    "steam:000000000000000",
}