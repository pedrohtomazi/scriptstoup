Config = {
  
Debug = 200, -- Don't TOUCH ! Only if you are on an support ticket with us !
    
CloudPort = "443", -- Choice the connection port with the CLOUD => "8080, 8081, 443"
    
StartAfter = 20, -- START SCRIPTS AFTER X SECONDS CHARACTER WAS SELECTED

ExternImagesInventory = false, -- false USE DEFAULT FRAMEWORK, or link FOR EXTERNAL DIRECTORY (Thanks Me Later...)
    
--RSG CONFIG
MaxInventoryWeight = 120000, -- MAX PLAYER INVENTORY WEIGHT
    
}